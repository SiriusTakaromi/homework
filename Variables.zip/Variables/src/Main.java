public class Main {
    public static void main(String[] args) {

        int vasyaAge;
        vasyaAge = 10;
        System.out.println("Vasya is " + vasyaAge + " years old.");
        vasyaAge = 10 + 1;
        System.out.println("Today is Vasya birthday, Vasya is " + vasyaAge + " years old.");
        int kolyaAge = 12;
        System.out.println("Kolya is " + kolyaAge + " years old.");
        int katyaAge, tonyaAge;
        katyaAge = tonyaAge = 13;
        System.out.println("Katya is " + katyaAge + " years old.");
        System.out.println("Tonya is " + tonyaAge + " years old.");
        tonyaAge = 14;
        System.out.println("There was a mistake in Tonya age, Tonya is " + tonyaAge + " years old.");
        System.out.print("Katya age remained the same " + katyaAge + " years old. ");
        katyaAge = katyaAge + 1;
        System.out.println("But tomorrow katya also will be " + katyaAge + " years old.");
        int boryaAge = 15;
        System.out.println("Borya is " + boryaAge + " years old.");
        boryaAge = boryaAge + 1;
        System.out.println("Yesterday was Borya birthday, now Borya is " + boryaAge + " years old.");
        boryaAge = boryaAge - 2;
        System.out.println("There was a mistake in Borya age, Borya was " + boryaAge + " years old, two days ago.");
        boryaAge = boryaAge + 1;
        System.out.println("But finally, Borya is " + boryaAge + " years old today.");
        System.out.println("Borya is " + boryaAge + " years old.");
        System.out.println("Katya is " + katyaAge + " years old.");
        System.out.println("Tonya is " + tonyaAge + " years old.");
        System.out.println("Kolya is " + kolyaAge + " years old.");
        System.out.println("Vasya is " + vasyaAge + " years old.");

    }
}