console.log("Start,");
for(i=1; i<=9; i++){
    console.log(i + ",");
}
console.log("finish.");

