let num = +prompt("Enter your number")
let sum = 0;
for(i=0;i<=num;i++){
    sum += i
}
console.log(sum);