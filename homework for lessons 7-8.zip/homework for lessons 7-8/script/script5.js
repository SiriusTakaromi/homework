
    let negative = 0;
    let positive = 0;
    let zero = 0;
    let even = 0;
    let odd = 0;

for(i=1; i<=10; i++){
    let num = +prompt('Enter ten numbers ' + i + '/10');
    console.log(num);

    if (num>0 && num%2 == 0){
        positive++;
        even++;
    }
    
    else if(num>0){
        positive++;
        odd++;
    }
    
    else if (num<0 && num%2 == 0){
        negative++;
        even++;
    }
    
    else if(num<0){
        negative++;
        odd++;
    }
    
    else{
    zero++;
    }
}


console.log("Negatives: " + negative);
console.log("Positive: " + positive);
console.log("Odd: " + odd);
console.log("Even: " + even);
console.log("Zero: " + zero);
