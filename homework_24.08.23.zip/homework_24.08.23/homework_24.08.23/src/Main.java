/*
Задание 1.
Сделайте перегруженные методы для перемножения 2-х, 3-х и 4-х чисел. В методе умножения 3-х чисел используйте вызов метода для 2-х чисел.
В методе умножения 4-х чисел – вызов метода для 3-х чисел.
        */

public class Main {
    public static int multiply(int a, int b) {
        return a * b;
    }

    public static int multiply(int a, int b, int c) {
        return multiply(multiply(a, b), c);
    }

    public static int multiply(int a, int b, int c, int d) {
        return multiply(multiply(a, b, c), d);
    }


    public static void main(String[] args) {
        System.out.println(multiply(2,4,6,2));
    }
}