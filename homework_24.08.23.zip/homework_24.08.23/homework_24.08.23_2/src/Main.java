/*
Задание 2.
Используя рекурсию, написать метод вычисления факториала числа n (n!), вводимого с клавиатуры.
*/

import java.util.Scanner;

public class Main {
    public static int factorial(int n) {
        if (n == 0)
            return 1;
        return factorial(n - 1) * n;
    }

    public static void main(String[] args) {
        System.out.print("Enter number: ");
        System.out.printf("result: %d", factorial(new Scanner(System.in).nextInt()));
     }
}