
/*
Задание 2.
Создайте массив из 5 строк. Используя метод length() строк,найдите строку с наибольшей длиной строк и с наименьшей длиной.
Выведите массив и полученный строки в консоль.
*/
import java.util.Arrays;



public class Main
{
    public static void main(String[] args)
    {
        String[] str = new String[] {"Water", "Fire", "Wind", "Lightning", "Earth",};
        System.out.println(Arrays.toString(str));
        int maxLength = 0;
        int minLength = Integer.MAX_VALUE;
        String longWord = "";
        String shortWord = "";
        for (int i = 0; i < str.length; i++)
        {
            if (str[i].length() > maxLength) {
                maxLength = str[i].length();
                longWord = str[i];
            }
        }
        for (int i = 0; i < str.length; i++) {
            if (str[i].length() < minLength){
                minLength = str[i].length();
                shortWord = str[i];
            }
        }
        System.out.println("Largest word is: " + longWord);
        System.out.println("Shortest word is: " + shortWord);









    }
}