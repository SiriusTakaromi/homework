/*
1 Создайте массив из 8 элементов. В массиве должны храниться даты (класс LocalDate).
Чтобы создать элемент LocalDate используйте метод LocalDate.of(год, месяц, день), где год, месяц и день – целые числа.
Выведите массив в консоль.
2 Напишите метод, который отсортирует массив дат по году. Выведите массив в консоль.
3 Напишите метод, который отсортирует массив дат по дню месяца. Выведите массив в консоль.
Сортировку можно выполнить по любому из изученных алгоритмов.
 */

import java.time.LocalDate;
import java.util.Arrays;

public class Main {
    private static final double FACTOR = 1.247;
    public static void main(String[] args) {
        LocalDate[] dates =
                {
                        LocalDate.of(2001, 12, 3),
                        LocalDate.of(2002, 2, 28),
                        LocalDate.of(2003, 4, 24),
                        LocalDate.of(2023, 5, 5),
                        LocalDate.of(2056, 9, 6),
                        LocalDate.of(2004, 7, 7),
                        LocalDate.of(1998, 1, 15),
                        LocalDate.of(1890, 3, 19),
                };
        System.out.println(Arrays.toString(dates));
        LocalDate[] cloned1 = Arrays.copyOf(dates, dates.length);
        sortByYear(cloned1);
        System.out.println(Arrays.toString(cloned1));
        LocalDate[] cloned2 = Arrays.copyOf(dates, dates.length);
        sortByDay(cloned2);
        System.out.println(Arrays.toString(cloned2));
        
    }

    private static void sortByYear(LocalDate[] dates) {
        int step = (int) (dates.length / FACTOR);
        boolean isSorted = false;
        while (!isSorted) {
            isSorted = true;
            for (int i = 0; i + step < dates.length; ++i) {
                if (dates[i].getYear() > dates[i + step].getYear()) {
                    swapValues(dates, i, i + step);
                    isSorted = false;
                }
            }
            step = (int) (step / FACTOR);
            if (step <= 1) step = 1;
        }
    }
    private static void sortByDay(LocalDate[] dates) {
        int step = (int) (dates.length / FACTOR);
        boolean isSorted = false;
        while (!isSorted) {
            isSorted = true;
            for (int i = 0; i + step < dates.length; ++i) {
                if (dates[i].getDayOfMonth() > dates[i + step].getDayOfMonth()) {
                    swapValues(dates, i, i + step);
                    isSorted = false;
                }
            }
            step = (int) (step / FACTOR);
            if (step <= 1) step = 1;
        }
    }





    private static  void swapValues (LocalDate[] array, int index1, int index2){ // {3, 4, 5}, index1 = 0, index2 = 2
        LocalDate temp = array[index1]; // temp = 3
        array[index1] = array[index2]; //array[index1] = 5
        array[index2] = temp; //array[index2] = 3  result = {5,4,3}
    }


}