public class Main {
    public static void main(String[] args) {
        System.out.println("SpaceX news! From Space"); //
        /*It's fake
        * Fake news
        * Just joke*/
        System.out.println(12*3);
        System.out.println(12/4);
        int a = 15;
        int b = 3;
        System.out.println(a-b);
    }
}