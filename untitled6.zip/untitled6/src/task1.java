


public class task1 {
    public static void main(String[] args) {
        System.out.println("Task 1.");
        System.out.println(" ");
       int k = 89;
       byte x = 4;
       char c = 'G';
       short souls;
       souls = 56;
       float money;
       double stats;
       long people;
       money = 4.7333436f;
       people = 12121L;
       stats = 4.355453532;

       System.out.println("char: " + c);
       System.out.println("int: " + k);
       System.out.println("byte: " + x);
       System.out.println("short:" + souls);
       System.out.println("float: " + money);
       System.out.println("double: " + stats);
       System.out.println("long: " + people);
       System.out.println(" ");
       System.out.println("Task 2.");
       System.out.println(" ");
       int sum = 345;
       System.out.println((sum%10)+((sum/10)%10)+((sum/100)%10));



        }






    public static byte[] intBytes(int value){
        byte[] bytes = new byte[4];
        bytes[0] = (byte)value;
        bytes[1] = (byte)(value >> 8);
        bytes[2] = (byte)(value >> 16);
        bytes[3] = (byte)(value >> 24);
        bytes[4] = (byte)(value >> 32);
        return bytes;
    }

}
