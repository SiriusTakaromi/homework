public class Main {
    public static void main(String[] args) {
        System.out.println("World news! From spaceX"); // It's test)
        /* spaceX said everything will OK
         * Nothing mean
         * I'm standing in Munich*/
        System.out.println(3+12);
        System.out.println(7*12);
        int a = 5;
        int b = 4;
        int c = 20;
        System.out.println(a/b);
        System.out.println(3+12*a);
        if (a * b == c) {
            System.out.println("true");
        }
            else {
                System.out.println("false");
        }
    }
}