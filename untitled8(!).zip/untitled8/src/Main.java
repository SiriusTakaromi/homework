public class Main {
    public static void main(String[] args) {

        int n = 345;
        System.out.print("sum " + n + " -> " + n/100 + "," + n%100/10 + "," + n%10);



    }
}