public class Main {
    public static void main(String[] args) {
        int d = 115;
        int n = 345;
        System.out.print("sum " + n + " -> " + n/d + "," + n%100/10 + "," + n%10);



    }
}